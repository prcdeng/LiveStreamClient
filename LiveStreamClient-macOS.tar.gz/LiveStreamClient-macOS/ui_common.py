"""两个 Tkinter 界面共用的样式与小部件。"""

from __future__ import annotations

import time
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk

BG = "#eef2f7"
CARD = "#ffffff"
BORDER = "#d7dee8"
TEXT = "#172033"
MUTED = "#64748b"
ACCENT = "#2563eb"
ACCENT_ACTIVE = "#1d4ed8"
GREEN = "#15803d"
ORANGE = "#b45309"
RED = "#b91c1c"
LOG_BG = "#0f172a"
LOG_TEXT = "#dbe4f0"

UI_FONT = "Microsoft YaHei UI"
MONO_FONT = "Consolas"

LEVEL_STYLE = {
    "info": ("信息", "#93c5fd"),
    "success": ("成功", "#86efac"),
    "warning": ("警告", "#fcd34d"),
    "error": ("错误", "#fca5a5"),
}


def apply_theme(root: tk.Tk) -> None:
    global UI_FONT, MONO_FONT
    families = set(tkfont.families(root))
    for candidate in (
        "Microsoft YaHei UI",
        "Microsoft YaHei",
        "Noto Sans CJK SC",
        "PingFang SC",
        "Segoe UI",
    ):
        if candidate in families:
            UI_FONT = candidate
            break
    for candidate in ("Consolas", "Cascadia Mono", "Menlo", "Monaco", "Courier New"):
        if candidate in families:
            MONO_FONT = candidate
            break

    root.configure(bg=BG)
    root.option_add("*Font", f"{{{UI_FONT}}} 10")

    style = ttk.Style(root)
    if "vista" in style.theme_names():
        style.theme_use("vista")
    style.configure(".", font=(UI_FONT, 10))
    style.configure("TButton", padding=(12, 5))
    style.configure("TEntry", padding=5)
    style.configure("TCombobox", padding=4)
    style.configure("Treeview", rowheight=27, font=(UI_FONT, 9))
    style.configure("Treeview.Heading", font=(UI_FONT, 9, "bold"))
    style.map("Treeview", background=[("selected", "#dbeafe")])


def center_window(root: tk.Tk, width: int, height: int) -> None:
    root.update_idletasks()
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    x = max(0, (screen_w - width) // 2)
    y = max(0, (screen_h - height) // 2 - 20)
    root.geometry(f"{width}x{height}+{x}+{y}")


def make_section(parent: tk.Misc, title: str | None = None) -> tuple[tk.Frame, tk.Frame]:
    outer = tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
    if title:
        tk.Label(
            outer,
            text=title,
            bg=CARD,
            fg=TEXT,
            font=(UI_FONT, 10, "bold"),
        ).pack(anchor="w", padx=14, pady=(11, 0))
    body = tk.Frame(outer, bg=CARD)
    body.pack(fill="both", expand=True, padx=14, pady=(9, 12))
    return outer, body


def make_metric_card(
    parent: tk.Misc, title: str, value: str = "—", accent: str = TEXT
) -> tuple[tk.Frame, tk.Label]:
    card = tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
    tk.Label(card, text=title, bg=CARD, fg=MUTED, font=(UI_FONT, 9)).pack(
        anchor="w", padx=13, pady=(10, 0)
    )
    value_label = tk.Label(
        card, text=value, bg=CARD, fg=accent, font=(UI_FONT, 17, "bold")
    )
    value_label.pack(anchor="w", padx=13, pady=(3, 10))
    return card, value_label


def make_status_badge(parent: tk.Misc, text: str = "● 未连接") -> tk.Label:
    return tk.Label(
        parent,
        text=text,
        bg=CARD,
        fg=MUTED,
        font=(UI_FONT, 10, "bold"),
        anchor="e",
    )


def set_status(badge: tk.Label, text: str, color: str) -> None:
    badge.configure(text=text, fg=color)


def make_primary_button(
    parent: tk.Misc,
    text: str,
    command,
    *,
    color: str = ACCENT,
    active_color: str = ACCENT_ACTIVE,
) -> tk.Button:
    return tk.Button(
        parent,
        text=text,
        command=command,
        bg=color,
        fg="white",
        activebackground=active_color,
        activeforeground="white",
        disabledforeground="#cbd5e1",
        relief="flat",
        bd=0,
        padx=20,
        pady=7,
        font=(UI_FONT, 10, "bold"),
        cursor="hand2",
        highlightthickness=0,
    )


def make_log_view(parent: tk.Misc, height: int = 10) -> tuple[tk.Frame, tk.Text]:
    wrapper = tk.Frame(parent, bg=LOG_BG, highlightbackground="#1e293b", highlightthickness=1)
    text = tk.Text(
        wrapper,
        height=height,
        bg=LOG_BG,
        fg=LOG_TEXT,
        insertbackground=LOG_TEXT,
        relief="flat",
        bd=0,
        wrap="word",
        padx=10,
        pady=8,
        font=(MONO_FONT, 9),
        state="disabled",
    )
    scroll = ttk.Scrollbar(wrapper, orient="vertical", command=text.yview)
    text.configure(yscrollcommand=scroll.set)
    wrapper.grid_rowconfigure(0, weight=1)
    wrapper.grid_columnconfigure(0, weight=1)
    text.grid(row=0, column=0, sticky="nsew")
    scroll.grid(row=0, column=1, sticky="ns")

    text.tag_configure("time", foreground="#64748b")
    for level, (label, color) in LEVEL_STYLE.items():
        text.tag_configure(level, foreground=color)
        text.tag_configure(f"{level}_label", foreground=color)
    return wrapper, text


def append_log(text: tk.Text, level: str, message: str) -> None:
    label, color = LEVEL_STYLE.get(level, ("信息", LOG_TEXT))
    stamp = time.strftime("%H:%M:%S")
    text.configure(state="normal")
    text.insert("end", f"{stamp}  ", "time")
    text.insert("end", f"{label}  ", f"{level}_label" if level in LEVEL_STYLE else "info_label")
    text.insert("end", f"{message}\n", level if level in LEVEL_STYLE else "info")
    line_count = int(text.index("end-1c").split(".", 1)[0])
    if line_count > 1500:
        text.delete("1.0", "500.0")
    text.see("end")
    text.configure(state="disabled")


def clear_log(text: tk.Text) -> None:
    text.configure(state="normal")
    text.delete("1.0", "end")
    text.configure(state="disabled")
