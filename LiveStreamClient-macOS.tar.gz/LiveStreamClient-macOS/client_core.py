"""直播接收客户端引擎（TCP/UDP，无界面）。"""

from __future__ import annotations

import secrets
import socket
import threading
import time
from collections import deque
from typing import Callable

from common import (
    CLIENT_HEARTBEAT_INTERVAL,
    CONNECT_TIMEOUT,
    COOKIE_SIZE,
    DATA_STALL_TIMEOUT,
    DEFAULT_PORT,
    DEFAULT_RATE_BPS,
    DEFAULT_TRANSPORT,
    HEADER_SIZE,
    LENGTH_PREFIX,
    MAX_FRAME_SIZE,
    PKT_ACK,
    PKT_CHALLENGE,
    PKT_CONFIRM,
    PKT_DATA,
    PKT_ERROR,
    PKT_HEARTBEAT,
    PKT_START,
    PKT_STOP,
    RATE_OPTIONS_BPS,
    SESSION_SIZE,
    TRANSPORTS,
    ZERO_SESSION,
    build_packet,
    build_subscribe,
    disable_udp_conn_reset,
    format_rate,
    frame_packet,
    is_valid_ipv4,
    parse_packet,
    wire_overhead,
)

LogCallback = Callable[[str, str], None]

STATE_IDLE = "idle"
STATE_CONNECTING = "connecting"
STATE_RECEIVING = "receiving"
STATE_STALLED = "stalled"
STATE_STOPPING = "stopping"
STATE_STOPPED = "stopped"
STATE_ERROR = "error"


class _FrameReader:
    """TCP 流按 4 字节长度前缀拆帧；UDP 直接返回数据报。"""

    def __init__(self, sock: socket.socket, framed: bool) -> None:
        self._sock = sock
        self._framed = framed
        self._buffer = bytearray()

    def recv(self) -> bytes:
        if not self._framed:
            return self._sock.recv(65535)
        while True:
            if len(self._buffer) >= LENGTH_PREFIX.size:
                size = LENGTH_PREFIX.unpack_from(self._buffer)[0]
                if size < HEADER_SIZE or size > MAX_FRAME_SIZE:
                    raise OSError("收到长度异常的 TCP 数据帧。")
                end = LENGTH_PREFIX.size + size
                if len(self._buffer) >= end:
                    frame = bytes(self._buffer[LENGTH_PREFIX.size:end])
                    del self._buffer[:end]
                    return frame
            chunk = self._sock.recv(65536)
            if not chunk:
                raise ConnectionAbortedError("服务端已关闭连接。")
            self._buffer.extend(chunk)


class LiveClient:
    def __init__(self, on_log: LogCallback | None = None) -> None:
        self._on_log = on_log
        self._lock = threading.RLock()
        self._send_lock = threading.Lock()
        self._sock: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()

        self._state = STATE_IDLE
        self._error = ""
        self._server_ip = ""
        self._bind_ip = ""
        self._port = DEFAULT_PORT
        self._transport = DEFAULT_TRANSPORT
        self._rate_bps = DEFAULT_RATE_BPS
        self._session = b"\x00" * SESSION_SIZE
        self._connected_at = 0.0
        self._last_data_at = 0.0
        self._stream_started_at = 0.0
        self._stalled_logged = False

        self._received_bytes = 0
        self._received_packets = 0
        self._wire_bytes = 0
        self._window: deque[tuple[float, int, int]] = deque()
        self._first_seq: int | None = None
        self._max_seq: int | None = None
        self._lost_packets = 0
        self._jitter_us = 0.0
        self._prev_transit_us: int | None = None

    # ------------------------------------------------------------------ 控制
    def start(
        self,
        server_ip: str,
        bind_ip: str,
        port: int = DEFAULT_PORT,
        *,
        transport: str = DEFAULT_TRANSPORT,
        rate_bps: int = DEFAULT_RATE_BPS,
    ) -> None:
        server_ip = server_ip.strip()
        transport = transport.strip().upper()
        if not is_valid_ipv4(server_ip):
            raise ValueError("服务端 IP 格式不正确，请输入 IPv4 地址，例如 192.168.1.10。")
        if not is_valid_ipv4(bind_ip):
            raise ValueError("请选择有效的本机网卡地址。")
        if transport not in TRANSPORTS:
            raise ValueError("传输协议必须为 TCP 或 UDP。")
        if rate_bps not in RATE_OPTIONS_BPS:
            raise ValueError("不支持的码率，请选择 1/2/4/8/16 Mbps。")

        with self._lock:
            if self._state in (STATE_CONNECTING, STATE_RECEIVING, STATE_STALLED, STATE_STOPPING):
                raise RuntimeError("当前连接尚未结束，请先停止。")
            old_thread = self._thread
        if old_thread is not None and old_thread.is_alive():
            self._stop_event.set()
            old_thread.join(timeout=1.0)
            if old_thread.is_alive():
                raise RuntimeError("上一次连接仍在关闭，请稍后重试。")

        with self._lock:
            self._state = STATE_CONNECTING
            self._error = ""
            self._server_ip = server_ip
            self._bind_ip = bind_ip
            self._port = port
            self._transport = transport
            self._rate_bps = rate_bps
            self._session = secrets.token_bytes(SESSION_SIZE)
            self._connected_at = 0.0
            self._last_data_at = 0.0
            self._stream_started_at = 0.0
            self._stalled_logged = False
            self._received_bytes = 0
            self._received_packets = 0
            self._wire_bytes = 0
            self._window.clear()
            self._first_seq = None
            self._max_seq = None
            self._lost_packets = 0
            self._jitter_us = 0.0
            self._prev_transit_us = None
            self._stop_event = threading.Event()
            self._thread = threading.Thread(
                target=self._run, name="live-client", daemon=True
            )
            thread = self._thread

        self._log(
            "info",
            f"正在连接 {server_ip}:{port}（{transport} · 目标 {format_rate(rate_bps)} · "
            f"本机网卡 {bind_ip}，会话 {self._session.hex()[:8]}）…",
        )
        thread.start()

    def stop(self) -> None:
        abort_connect = False
        with self._lock:
            if self._state in (STATE_IDLE, STATE_STOPPED, STATE_ERROR):
                return
            sock = self._sock
            session = self._session
            transport = self._transport
            if self._state != STATE_STOPPING:
                abort_connect = self._state == STATE_CONNECTING
                self._state = STATE_STOPPING
                self._log("info", "正在停止接收…")
            self._stop_event.set()
        if sock is not None and session != ZERO_SESSION:
            for _ in range(3):
                try:
                    self._send_control(sock, transport, PKT_STOP, session)
                except OSError:
                    break
        if abort_connect and sock is not None:
            try:
                sock.close()
            except OSError:
                pass

    def shutdown(self, timeout: float = 1.5) -> None:
        self.stop()
        with self._lock:
            thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=timeout)

    # ------------------------------------------------------------------ 连接线程
    def _run(self) -> None:
        sock: socket.socket | None = None
        transport = self._transport
        connected = False
        fatal_error = ""
        stopped_by_user = False

        try:
            if transport == "UDP":
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                disable_udp_conn_reset(sock)
                try:
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 * 1024 * 1024)
                except OSError:
                    pass
                sock.bind((self._bind_ip, 0))
                sock.connect((self._server_ip, self._port))
                sock.settimeout(0.05)
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                try:
                    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 8 * 1024 * 1024)
                except OSError:
                    pass
                sock.settimeout(CONNECT_TIMEOUT)
                sock.bind((self._bind_ip, 0))
                sock.connect((self._server_ip, self._port))
                sock.settimeout(0.05)
            with self._lock:
                self._sock = sock

            reader = _FrameReader(sock, transport == "TCP")
            ok, reason = self._handshake(sock, reader)
            if not ok:
                if self._stop_event.is_set():
                    stopped_by_user = True
                else:
                    fatal_error = reason or "连接失败。"
            else:
                connected = True
                now = time.perf_counter()
                with self._lock:
                    self._state = STATE_RECEIVING
                    self._connected_at = now
                    self._last_data_at = now
                self._log(
                    "success",
                    f"连接成功，开始接收 {self._server_ip}:{self._port} 的 "
                    f"{self._transport} 直播流（目标 {format_rate(self._rate_bps)}）。",
                )
                fatal_error = self._receive_loop(sock, reader)

        except OSError as exc:
            if self._stop_event.is_set():
                stopped_by_user = True
            else:
                fatal_error = self._network_error_text(exc)
        except Exception as exc:  # 防止后台线程直接崩溃
            fatal_error = f"客户端内部错误：{exc}"
        finally:
            if sock is not None:
                try:
                    self._send_control(sock, transport, PKT_STOP, self._session)
                except OSError:
                    pass
                try:
                    sock.close()
                except OSError:
                    pass

            with self._lock:
                self._sock = None
                received = self._received_packets
                lost = self._lost_packets
                if fatal_error:
                    self._state = STATE_ERROR
                    self._error = fatal_error
                else:
                    self._state = STATE_STOPPED
                    self._error = ""

            if fatal_error:
                self._log("error", fatal_error)
            elif stopped_by_user or connected:
                self._log(
                    "info",
                    f"已停止接收，共收到 {received} 个数据包，按序号估算丢包 {lost} 个。",
                )

    def _handshake(self, sock: socket.socket, reader: _FrameReader) -> tuple[bool, str | None]:
        deadline = time.perf_counter() + CONNECT_TIMEOUT
        next_start = 0.0
        cookie: bytes | None = None
        next_confirm = 0.0
        subscribe_body = build_subscribe(self._transport, self._rate_bps)

        while time.perf_counter() < deadline:
            if self._stop_event.is_set():
                return False, None
            now = time.perf_counter()
            try:
                if cookie is None and now >= next_start:
                    self._send_control(
                        sock, self._transport, PKT_START, self._session, subscribe_body
                    )
                    next_start = now + 0.4
                elif cookie is not None and now >= next_confirm:
                    self._send_control(
                        sock, self._transport, PKT_CONFIRM, self._session, cookie
                    )
                    next_confirm = now + 0.4

                data = reader.recv()
            except socket.timeout:
                continue
            except OSError as exc:
                if self._stop_event.is_set():
                    return False, None
                return False, self._network_error_text(exc)

            packet = parse_packet(data)
            if packet is None or packet.session != self._session:
                continue
            if packet.pkt_type == PKT_CHALLENGE:
                if len(packet.body) >= COOKIE_SIZE:
                    cookie = packet.body[:COOKIE_SIZE]
                    next_confirm = 0.0
            elif packet.pkt_type == PKT_ACK:
                return True, None
            elif packet.pkt_type == PKT_DATA:
                return True, None
            elif packet.pkt_type == PKT_ERROR:
                reason = packet.body.decode("utf-8", errors="replace") or "服务端拒绝连接。"
                return False, reason

        return (
            False,
            f"连接超时：服务端未响应。请检查服务端 IP、{self._transport} {self._port} 端口、"
            "所选网卡及 Windows 防火墙。",
        )

    def _receive_loop(self, sock: socket.socket, reader: _FrameReader) -> str:
        last_heartbeat = 0.0

        while not self._stop_event.is_set():
            now = time.perf_counter()
            if now - last_heartbeat >= CLIENT_HEARTBEAT_INTERVAL:
                try:
                    self._send_control(
                        sock, self._transport, PKT_HEARTBEAT, self._session
                    )
                except OSError as exc:
                    if self._stop_event.is_set():
                        return ""
                    return self._network_error_text(exc)
                last_heartbeat = now

            try:
                data = reader.recv()
            except socket.timeout:
                self._check_stall(time.perf_counter())
                continue
            except OSError as exc:
                if self._stop_event.is_set():
                    return ""
                return self._network_error_text(exc)

            now = time.perf_counter()
            packet = parse_packet(data)
            if packet is None:
                continue
            if packet.pkt_type == PKT_DATA:
                self._on_data(packet, len(data), now)
            elif packet.pkt_type == PKT_ERROR:
                reason = packet.body.decode("utf-8", errors="replace") or "服务端终止了会话。"
                return reason
            elif packet.pkt_type == PKT_ACK:
                continue

            self._check_stall(now)

        return ""

    # ------------------------------------------------------------------ 统计
    def _on_data(self, packet, datagram_size: int, now: float) -> None:
        arrival_us = time.perf_counter_ns() // 1000
        wire_size = datagram_size + wire_overhead(self._transport)
        resumed = False

        with self._lock:
            if self._stream_started_at == 0.0:
                self._stream_started_at = now
                self._first_seq = packet.seq
                self._max_seq = packet.seq
            elif packet.seq > self._max_seq:
                self._lost_packets += packet.seq - self._max_seq - 1
                self._max_seq = packet.seq

            self._last_data_at = now
            self._received_packets += 1
            self._received_bytes += datagram_size
            self._wire_bytes += wire_size
            self._window.append((now, datagram_size, wire_size))
            cutoff = now - 1.0
            while self._window and self._window[0][0] < cutoff:
                self._window.popleft()

            transit_us = arrival_us - packet.timestamp_us
            if self._prev_transit_us is not None:
                delta = abs(transit_us - self._prev_transit_us)
                self._jitter_us += (delta - self._jitter_us) / 16.0
            self._prev_transit_us = transit_us

            if self._state == STATE_STALLED:
                self._state = STATE_RECEIVING
                self._stalled_logged = False
                resumed = True

        if resumed:
            self._log("success", "数据流已恢复。")

    def _check_stall(self, now: float) -> None:
        should_log = False
        with self._lock:
            if (
                self._state == STATE_RECEIVING
                and self._last_data_at > 0.0
                and now - self._last_data_at > DATA_STALL_TIMEOUT
            ):
                self._state = STATE_STALLED
                if not self._stalled_logged:
                    self._stalled_logged = True
                    should_log = True
        if should_log:
            self._log(
                "warning",
                f"已超过 {DATA_STALL_TIMEOUT:.0f} 秒未收到数据，当前显示为信号中断；"
                "连接仍保持，可点击停止后重试。",
            )

    def snapshot(self) -> dict:
        now = time.perf_counter()
        with self._lock:
            window = self._window
            cutoff = now - 1.0
            while window and window[0][0] < cutoff:
                window.popleft()

            if self._stream_started_at > 0.0:
                span = max(0.25, min(1.0, now - self._stream_started_at))
            else:
                span = 0.0
            window_bytes = sum(item[1] for item in window)
            window_wire = sum(item[2] for item in window)
            payload_bps = (window_bytes * 8.0 / span) if span else 0.0
            wire_bps = (window_wire * 8.0 / span) if span else 0.0

            if self._first_seq is None or self._max_seq is None:
                expected = 0
                loss_rate = 0.0
            else:
                expected = self._max_seq - self._first_seq + 1
                loss_rate = (self._lost_packets / expected) if expected > 0 else 0.0

            state = self._state
            connected_seconds = (
                now - self._connected_at if self._connected_at > 0.0 else 0.0
            )
            if state == STATE_STALLED:
                payload_bps = 0.0
                wire_bps = 0.0

            return {
                "state": state,
                "error": self._error,
                "server_ip": self._server_ip,
                "bind_ip": self._bind_ip,
                "port": self._port,
                "transport": self._transport,
                "rate_bps": self._rate_bps,
                "target_rate_text": format_rate(self._rate_bps),
                "session": self._session.hex()[:8],
                "connected_seconds": connected_seconds,
                "payload_bps": payload_bps,
                "wire_bps": wire_bps,
                "received_bytes": self._received_bytes,
                "received_packets": self._received_packets,
                "expected_packets": expected,
                "lost_packets": self._lost_packets,
                "loss_rate": loss_rate,
                "jitter_ms": self._jitter_us / 1000.0,
            }

    # ------------------------------------------------------------------ 工具
    def _send_control(
        self,
        sock: socket.socket,
        transport: str,
        pkt_type: int,
        session: bytes,
        body: bytes = b"",
    ) -> None:
        data = build_packet(pkt_type, session=session, body=body)
        with self._send_lock:
            if transport == "TCP":
                sock.sendall(frame_packet(data))
            else:
                sock.send(data)

    def _network_error_text(self, exc: OSError) -> str:
        return (
            f"网络错误：{exc}。请确认服务端已启动并开放 {self._transport} {self._port}，"
            "Windows 防火墙已放行，且所选网卡与服务端 IP 路由匹配。"
        )

    def _log(self, level: str, message: str) -> None:
        callback = self._on_log
        if callback is None:
            return
        try:
            callback(level, message)
        except Exception:
            pass
