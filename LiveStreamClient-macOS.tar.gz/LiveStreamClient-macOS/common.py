"""udp_live_sim 的公共协议、网卡枚举与格式化工具。"""

from __future__ import annotations

import contextlib
import os
import socket
import struct
import subprocess
import sys
import time
from dataclasses import dataclass
from typing import Iterator

try:
    import psutil
except ImportError:  # pragma: no cover - 仅在源码环境缺少依赖时兜底
    psutil = None


APP_NAME = "直播流量模拟"
SERVER_TITLE = "直播流量模拟 · 服务端"
CLIENT_TITLE = "直播流量模拟 · 客户端"
VERSION = "2.0.0"

DEFAULT_PORT = 9010
DEFAULT_SERVER_IP = "10.104.123.246"
HOST = "0.0.0.0"

MAGIC = b"LSM1"
PROTOCOL_VERSION = 2

# 每个数据包固定 1250 字节（含 32 字节协议头），码率由包速率决定。
PACKET_SIZE = 1250
PACKETS_PER_FRAME = 8
IP_UDP_OVERHEAD = 28
TCP_IP_OVERHEAD = 40
TCP_FRAME_OVERHEAD = 4

RATE_OPTIONS_BPS = (1_000_000, 2_000_000, 4_000_000, 8_000_000, 16_000_000)
DEFAULT_RATE_BPS = 2_000_000
RATE_LABELS = {bps: f"{bps // 1_000_000} Mbps" for bps in RATE_OPTIONS_BPS}
RATE_BY_LABEL = {label: bps for bps, label in RATE_LABELS.items()}

TRANSPORT_UDP = 0
TRANSPORT_TCP = 1
TRANSPORTS = ("UDP", "TCP")
DEFAULT_TRANSPORT = "UDP"
TRANSPORT_CODES = {name: code for code, name in ((TRANSPORT_UDP, "UDP"), (TRANSPORT_TCP, "TCP"))}
TRANSPORT_NAMES = {code: name for name, code in TRANSPORT_CODES.items()}

SUBSCRIBE = struct.Struct("!BI")  # 传输协议编码 + 目标码率
LENGTH_PREFIX = struct.Struct("!I")  # TCP 数据帧长度前缀
MAX_FRAME_SIZE = 65536
HEADER = struct.Struct("!4sBBHIIQ8s")
HEADER_SIZE = HEADER.size  # 32
MEDIA_SIZE = PACKET_SIZE - HEADER_SIZE
SESSION_SIZE = 8
COOKIE_SIZE = 16
ZERO_SESSION = b"\x00" * SESSION_SIZE

PKT_DATA = 0
PKT_START = 1
PKT_STOP = 2
PKT_ACK = 3
PKT_HEARTBEAT = 4
PKT_ERROR = 5
PKT_CHALLENGE = 6
PKT_CONFIRM = 7

TYPE_NAMES = {
    PKT_DATA: "DATA",
    PKT_START: "START",
    PKT_STOP: "STOP",
    PKT_ACK: "ACK",
    PKT_HEARTBEAT: "HEARTBEAT",
    PKT_ERROR: "ERROR",
    PKT_CHALLENGE: "CHALLENGE",
    PKT_CONFIRM: "CONFIRM",
}

FLAG_FRAME_END = 0x0001

CLIENT_HEARTBEAT_INTERVAL = 1.0
SERVER_CLIENT_TIMEOUT = 5.0
PENDING_TIMEOUT = 10.0
CONNECT_TIMEOUT = 4.0
DATA_STALL_TIMEOUT = 2.0
MAX_CLIENTS = 32


@dataclass(frozen=True)
class Packet:
    pkt_type: int
    flags: int
    seq: int
    frame_id: int
    timestamp_us: int
    session: bytes
    body: bytes


def build_packet(
    pkt_type: int,
    *,
    session: bytes = ZERO_SESSION,
    seq: int = 0,
    frame_id: int = 0,
    flags: int = 0,
    timestamp_us: int | None = None,
    body: bytes = b"",
) -> bytes:
    if len(session) != SESSION_SIZE:
        raise ValueError("session 必须为 8 字节")
    if timestamp_us is None:
        timestamp_us = monotonic_us()
    header = HEADER.pack(
        MAGIC,
        PROTOCOL_VERSION,
        pkt_type,
        flags,
        seq & 0xFFFFFFFF,
        frame_id & 0xFFFFFFFF,
        timestamp_us & 0xFFFFFFFFFFFFFFFF,
        session,
    )
    return header + body


def parse_packet(data: bytes) -> Packet | None:
    if len(data) < HEADER_SIZE:
        return None
    magic, version, pkt_type, flags, seq, frame_id, timestamp_us, session = HEADER.unpack_from(data)
    if magic != MAGIC or version != PROTOCOL_VERSION:
        return None
    if pkt_type > PKT_CONFIRM:
        return None
    return Packet(pkt_type, flags, seq, frame_id, timestamp_us, session, data[HEADER_SIZE:])


def build_subscribe(transport: str, rate_bps: int) -> bytes:
    code = TRANSPORT_CODES.get(transport.strip().upper())
    if code is None:
        raise ValueError("传输协议必须为 TCP 或 UDP。")
    if rate_bps not in RATE_OPTIONS_BPS:
        raise ValueError("不支持的码率。")
    return SUBSCRIBE.pack(code, rate_bps)


def parse_subscribe(body: bytes) -> tuple[str, int] | None:
    if len(body) < SUBSCRIBE.size:
        return None
    code, rate_bps = SUBSCRIBE.unpack_from(body)
    transport = TRANSPORT_NAMES.get(code)
    if transport is None or rate_bps not in RATE_OPTIONS_BPS:
        return None
    return transport, rate_bps


def packets_per_second(rate_bps: int) -> int:
    return max(1, rate_bps // (PACKET_SIZE * 8))


def wire_overhead(transport: str) -> int:
    """估算每个数据包除 1250 字节载荷外的协议开销。"""
    if transport == "TCP":
        return TCP_FRAME_OVERHEAD + TCP_IP_OVERHEAD
    return IP_UDP_OVERHEAD


def frame_packet(data: bytes) -> bytes:
    return LENGTH_PREFIX.pack(len(data)) + data


def monotonic_us() -> int:
    return time.perf_counter_ns() // 1000


def normalize_mac(value: str) -> str:
    """把 aa-bb-cc-dd-ee-ff / aabb.ccdd.eeff 等写法统一为 AA:BB:CC:DD:EE:FF。"""
    digits = "".join(ch for ch in value if ch.isalnum())
    if len(digits) != 12 or any(ch not in "0123456789abcdefABCDEF" for ch in digits):
        return ""
    if not any(ch != "0" for ch in digits):
        return ""
    digits = digits.upper()
    return ":".join(digits[index : index + 2] for index in range(0, 12, 2))


@dataclass(frozen=True)
class NicAddress:
    name: str
    ip: str
    is_loopback: bool
    is_up: bool
    mac: str = ""

    @property
    def label(self) -> str:
        state = "" if self.is_up else "（未启用）"
        return f"{self.name} — {self.ip}{state}"


def _fallback_nic_addresses() -> list[NicAddress]:
    addresses: list[NicAddress] = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not any(item.ip == ip for item in addresses):
                addresses.append(NicAddress("本机网卡", ip, ip.startswith("127."), True))
    except OSError:
        pass
    return addresses


def _parse_ifconfig_output(text: str) -> list[NicAddress]:
    """解析 macOS ifconfig 输出，供未安装 psutil 时使用。"""
    addresses: list[NicAddress] = []
    current: tuple[str, bool] | None = None
    current_mac = ""
    for raw in text.splitlines():
        if not raw.strip():
            continue
        if not raw[0].isspace():
            name, _, rest = raw.partition(":")
            flags = rest.split("<", 1)[1].split(">", 1)[0] if "<" in rest else ""
            current = (name.strip(), "UP" in flags.split(",")) if name.strip() else None
            current_mac = ""
            continue
        parts = raw.split()
        if current is None or len(parts) < 2:
            continue
        if parts[0] == "ether":
            current_mac = normalize_mac(parts[1])
            continue
        if parts[0] != "inet":
            continue
        ip = parts[1].split("%", 1)[0]
        if not ip or ip == "0.0.0.0":
            continue
        addresses.append(
            NicAddress(current[0], ip, ip.startswith("127."), current[1], current_mac)
        )
    return addresses


def _ifconfig_nic_addresses(include_down: bool) -> list[NicAddress] | None:
    try:
        result = subprocess.run(
            ["ifconfig"], capture_output=True, text=True, timeout=3, check=False
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0 or not result.stdout.strip():
        return None
    addresses = _parse_ifconfig_output(result.stdout)
    addresses = [item for item in addresses if include_down or item.is_up]
    addresses.sort(key=lambda item: (not item.is_up, item.is_loopback, item.name.lower(), item.ip))
    return addresses or None


def list_ipv4_interfaces(include_down: bool = False) -> list[NicAddress]:
    """列出 IPv4 网卡地址；同一网卡的多个 IP 会各占一项。"""
    if psutil is None:
        if sys.platform == "darwin":
            fallback = _ifconfig_nic_addresses(include_down)
            if fallback is not None:
                return fallback
        return _fallback_nic_addresses()

    try:
        stats = psutil.net_if_stats()
        iface_addrs = psutil.net_if_addrs()
    except (OSError, psutil.Error):
        if sys.platform == "darwin":
            fallback = _ifconfig_nic_addresses(include_down)
            if fallback is not None:
                return fallback
        return _fallback_nic_addresses()

    result: list[NicAddress] = []
    seen: set[tuple[str, str]] = set()
    mac_by_name: dict[str, str] = {}
    for name, entries in iface_addrs.items():
        for entry in entries:
            if entry.family != psutil.AF_LINK:
                continue
            mac = normalize_mac(entry.address)
            if mac:
                mac_by_name[name] = mac
                break

    for name, entries in iface_addrs.items():
        stat = stats.get(name)
        is_up = bool(stat.isup) if stat is not None else True
        if not include_down and not is_up:
            continue
        mac = mac_by_name.get(name, "")
        for entry in entries:
            if entry.family != socket.AF_INET:
                continue
            ip = entry.address.split("%", 1)[0]
            if not ip or ip == "0.0.0.0":
                continue
            key = (name, ip)
            if key in seen:
                continue
            seen.add(key)
            result.append(NicAddress(name, ip, ip.startswith("127."), is_up, mac))

    result.sort(key=lambda item: (not item.is_up, item.is_loopback, item.name.lower(), item.ip))
    return result


def find_nic_by_ip(ip: str, include_down: bool = True) -> NicAddress | None:
    for item in list_ipv4_interfaces(include_down=include_down):
        if item.ip == ip:
            return item
    return None


def route_source_ip(server_ip: str, port: int = DEFAULT_PORT) -> str | None:
    """按系统路由表返回访问服务端时会使用的本机 IPv4，无法判断时返回 None。"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect((server_ip, port))
        return str(sock.getsockname()[0])
    except OSError:
        return None
    finally:
        sock.close()


def is_valid_ipv4(value: str) -> bool:
    parts = value.strip().split(".")
    if len(parts) != 4:
        return False
    try:
        numbers = [int(part) for part in parts]
    except ValueError:
        return False
    return all(0 <= number <= 255 for number in numbers) and all(
        part == str(number) for part, number in zip(parts, numbers)
    )


def format_rate(bps: float) -> str:
    if bps >= 1_000_000:
        return f"{bps / 1_000_000:.2f} Mbps"
    if bps >= 1_000:
        return f"{bps / 1_000:.1f} Kbps"
    return f"{bps:.0f} bps"


def format_bytes(size: float) -> str:
    units = ("B", "KB", "MB", "GB", "TB")
    value = float(size)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.0f} {unit}" if unit == "B" else f"{value:.2f} {unit}"
        value /= 1024
    return f"{value:.2f} TB"


def format_duration(seconds: float) -> str:
    total = max(0, int(seconds))
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours:
        return f"{hours:d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def enable_dpi_awareness() -> None:
    try:
        import ctypes

        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def disable_udp_conn_reset(sock: socket.socket) -> None:
    """Windows 下避免客户端关闭端口产生的 ICMP 导致 recv 报 WSAECONNRESET。"""
    if os.name != "nt":
        return
    try:
        sock.ioctl(0x9800000C, False)  # SIO_UDP_CONNRESET
    except (OSError, ValueError):
        pass


@contextlib.contextmanager
def high_resolution_timer(period_ms: int = 1) -> Iterator[None]:
    """提高 Windows 定时器精度，退出时恢复。"""
    try:
        import ctypes

        winmm = ctypes.WinDLL("winmm")
        winmm.timeBeginPeriod(period_ms)
    except Exception:
        yield
        return

    try:
        yield
    finally:
        try:
            winmm.timeEndPeriod(period_ms)
        except Exception:
            pass
