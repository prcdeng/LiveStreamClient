"""直播流量模拟 - 客户端图形界面。"""

from __future__ import annotations

import queue
import sys
import tkinter as tk
from tkinter import messagebox, ttk

from client_core import (
    STATE_CONNECTING,
    STATE_ERROR,
    STATE_IDLE,
    STATE_RECEIVING,
    STATE_STALLED,
    STATE_STOPPED,
    STATE_STOPPING,
    LiveClient,
)
from common import (
    CLIENT_TITLE,
    DEFAULT_PORT,
    DEFAULT_RATE_BPS,
    DEFAULT_SERVER_IP,
    DEFAULT_TRANSPORT,
    NicAddress,
    RATE_BY_LABEL,
    RATE_LABELS,
    RATE_OPTIONS_BPS,
    TRANSPORTS,
    enable_dpi_awareness,
    format_bytes,
    format_duration,
    format_rate,
    is_valid_ipv4,
    list_ipv4_interfaces,
    route_source_ip,
)
from ui_common import (
    ACCENT,
    BG,
    CARD,
    GREEN,
    MONO_FONT,
    MUTED,
    ORANGE,
    RED,
    TEXT,
    UI_FONT,
    append_log,
    apply_theme,
    center_window,
    clear_log,
    make_log_view,
    make_metric_card,
    make_primary_button,
    make_section,
    make_status_badge,
    set_status,
)

STATE_TEXT = {
    STATE_IDLE: ("● 未连接", MUTED),
    STATE_CONNECTING: ("● 正在连接…", ORANGE),
    STATE_RECEIVING: ("● 正在接收", GREEN),
    STATE_STALLED: ("● 信号中断", RED),
    STATE_STOPPING: ("● 正在停止…", ORANGE),
    STATE_STOPPED: ("● 已停止", MUTED),
    STATE_ERROR: ("● 连接失败", RED),
}
ACTIVE_STATES = {STATE_CONNECTING, STATE_RECEIVING, STATE_STALLED, STATE_STOPPING}


class ClientApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title(CLIENT_TITLE)
        self.root.minsize(960, 680)
        apply_theme(root)
        center_window(root, 1000, 820)

        self._closing = False
        self._client_state = STATE_IDLE
        self._controls_state: str | None = None
        self._log_queue: queue.Queue[tuple[str, str]] = queue.Queue()
        self._nic_map: dict[str, NicAddress] = {}
        self._notice_visible = False
        self.client = LiveClient(on_log=self._enqueue_log)

        self._build_ui()
        self._refresh_nics()
        self._update_controls(STATE_IDLE)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        if sys.platform == "darwin":
            self.root.createcommand("tk::mac::Quit", self._on_close)
        self.root.after(150, self._drain_logs)
        self.root.after(250, self._poll)
        self.server_entry.focus_set()

    # ------------------------------------------------------------------ 界面
    def _build_ui(self) -> None:
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=20, pady=(16, 0))
        title_box = tk.Frame(header, bg=BG)
        title_box.pack(side="left", fill="x", expand=True)
        tk.Label(
            title_box,
            text="直播流量模拟",
            bg=BG,
            fg=TEXT,
            font=(UI_FONT, 19, "bold"),
        ).pack(anchor="w")
        tk.Label(
            title_box,
            text="客户端 · 选择 TCP/UDP 与 1–16 Mbps 码率，填写服务端 IP 与网卡后开始接收",
            bg=BG,
            fg=MUTED,
            font=(UI_FONT, 9),
        ).pack(anchor="w", pady=(2, 0))
        self.status_badge = make_status_badge(header, "● 未连接")
        self.status_badge.configure(bg=BG, font=(UI_FONT, 11, "bold"))
        self.status_badge.pack(side="right", padx=(12, 0), pady=(4, 0))

        content = tk.Frame(self.root, bg=BG)
        content.pack(fill="both", expand=True, padx=20, pady=14)

        settings_outer, settings = make_section(content, "连接设置")
        settings_outer.pack(fill="x")

        label_args = {"bg": CARD, "fg": MUTED, "font": (UI_FONT, 9)}
        top_row = tk.Frame(settings, bg=CARD)
        top_row.pack(fill="x")
        tk.Label(top_row, text="服务端 IP", **label_args).pack(side="left", padx=(0, 8))
        self.server_var = tk.StringVar(value=DEFAULT_SERVER_IP)
        self.server_entry = ttk.Entry(top_row, textvariable=self.server_var, width=20)
        self.server_entry.pack(side="left", padx=(0, 18), ipady=2)

        tk.Label(top_row, text="端口", **label_args).pack(side="left", padx=(0, 6))
        tk.Label(
            top_row,
            text=str(DEFAULT_PORT),
            bg=CARD,
            fg=TEXT,
            font=(UI_FONT, 10, "bold"),
        ).pack(side="left", padx=(0, 18))

        tk.Label(top_row, text="传输协议", **label_args).pack(side="left", padx=(0, 6))
        self.transport_var = tk.StringVar(value=DEFAULT_TRANSPORT)
        self.transport_combo = ttk.Combobox(
            top_row,
            textvariable=self.transport_var,
            state="readonly",
            values=list(TRANSPORTS),
            width=7,
        )
        self.transport_combo.pack(side="left", padx=(0, 18))

        tk.Label(top_row, text="目标码率", **label_args).pack(side="left", padx=(0, 6))
        self.rate_var = tk.StringVar(value=RATE_LABELS[DEFAULT_RATE_BPS])
        self.rate_combo = ttk.Combobox(
            top_row,
            textvariable=self.rate_var,
            state="readonly",
            values=[RATE_LABELS[bps] for bps in RATE_OPTIONS_BPS],
            width=9,
        )
        self.rate_combo.pack(side="left")
        self.transport_combo.bind("<<ComboboxSelected>>", self._on_selection_change)
        self.rate_combo.bind("<<ComboboxSelected>>", self._on_selection_change)

        nic_tools = tk.Frame(top_row, bg=CARD)
        nic_tools.pack(side="right")
        self.refresh_button = ttk.Button(nic_tools, text="刷新网卡", width=9, command=self._refresh_nics)
        self.refresh_button.pack(side="left", padx=(0, 4))
        self.match_button = ttk.Button(nic_tools, text="按 IP 匹配", width=9, command=self._match_nic)
        self.match_button.pack(side="left")

        nic_row = tk.Frame(settings, bg=CARD)
        nic_row.pack(fill="x", pady=(10, 0))
        tk.Label(nic_row, text="本机网卡", **label_args).pack(side="left", padx=(0, 8))
        self.nic_var = tk.StringVar()
        self.nic_combo = ttk.Combobox(
            nic_row, textvariable=self.nic_var, state="readonly", width=42
        )
        self.nic_combo.pack(side="left", fill="x", expand=True)
        self.nic_combo.bind("<<ComboboxSelected>>", self._on_nic_selected)

        tk.Label(nic_row, text="本机 MAC", **label_args).pack(side="left", padx=(16, 6))
        self.mac_var = tk.StringVar(value="不可用")
        self.mac_value_label = tk.Label(
            nic_row,
            textvariable=self.mac_var,
            bg=CARD,
            fg=MUTED,
            font=(MONO_FONT, 10, "bold"),
            width=17,
            anchor="w",
        )
        self.mac_value_label.pack(side="left")

        footer = tk.Frame(settings, bg=CARD)
        footer.pack(fill="x", pady=(10, 0))
        actions = tk.Frame(footer, bg=CARD)
        actions.pack(side="right")
        self.start_button = make_primary_button(actions, "开始收看", self._on_start)
        self.start_button.configure(width=11)
        self.start_button.pack(side="left", padx=(0, 8))
        self.stop_button = make_primary_button(
            actions, "停止接收", self._on_stop, color=RED, active_color="#991b1b"
        )
        self.stop_button.configure(width=11)
        self.stop_button.pack(side="left")
        tk.Label(
            footer,
            text=f"TCP/UDP 共用端口 {DEFAULT_PORT}；不确定网卡时填写服务端 IP 后点“按 IP 匹配”自动选择。",
            bg=CARD,
            fg=MUTED,
            font=(UI_FONT, 9),
            justify="left",
            anchor="w",
        ).pack(side="left", fill="x", expand=True, padx=(0, 12))

        self.detail_label = tk.Label(
            content,
            text="请选择传输协议与目标码率，填写服务端 IP、选择本机网卡，然后点击“开始收看”。",
            bg=BG,
            fg=MUTED,
            font=(UI_FONT, 9),
            anchor="w",
            justify="left",
            wraplength=900,
        )
        self.detail_label.pack(fill="x", pady=(10, 0))

        self.notice_label = tk.Label(
            content,
            text="",
            bg=BG,
            fg=RED,
            font=(UI_FONT, 9),
            anchor="w",
            justify="left",
            wraplength=900,
        )

        metrics_outer, metrics = make_section(
            content, self._metrics_title()
        )
        self.metrics_title_label = metrics_outer.winfo_children()[0]
        metrics_outer.pack(fill="x", pady=(10, 0))
        for column in range(3):
            metrics.grid_columnconfigure(column, weight=1, uniform="metric")

        card, self.rate_value = make_metric_card(metrics, "接收码率（载荷）", "0.00 Mbps", GREEN)
        card.grid(row=0, column=0, sticky="nsew", padx=(0, 4), pady=(0, 8))
        card, self.wire_value = make_metric_card(metrics, "估算线速（含协议开销）", "0.00 Mbps", ACCENT)
        card.grid(row=0, column=1, sticky="nsew", padx=4, pady=(0, 8))
        card, self.bytes_value = make_metric_card(metrics, "累计接收", "0 B", TEXT)
        card.grid(row=0, column=2, sticky="nsew", padx=(4, 0), pady=(0, 8))

        card, self.packets_value = make_metric_card(metrics, "数据包", "0", TEXT)
        card.grid(row=1, column=0, sticky="nsew", padx=(0, 4))
        card, self.loss_value = make_metric_card(metrics, "丢包率（按序号估算）", "0.00%", GREEN)
        card.grid(row=1, column=1, sticky="nsew", padx=4)
        card, self.jitter_value = make_metric_card(metrics, "单向抖动（估算）", "0.000 ms", TEXT)
        card.grid(row=1, column=2, sticky="nsew", padx=(4, 0))

        tk.Label(
            metrics,
            text=(
                "码率按最近 1 秒实际收到的载荷计算；线速为估算值：UDP 每包加 28 字节 IP/UDP 头，"
                "TCP 每包加 4 字节帧头与约 40 字节 TCP/IP 头，未计重传与确认包。"
            ),
            bg=CARD,
            fg=MUTED,
            font=(UI_FONT, 8),
            anchor="w",
        ).grid(row=2, column=0, columnspan=3, sticky="w", pady=(8, 0))

        log_outer, log_body = make_section(content, "运行日志")
        log_outer.pack(fill="both", expand=True, pady=(10, 0))
        log_toolbar = tk.Frame(log_body, bg=CARD)
        log_toolbar.pack(fill="x", pady=(0, 6))
        tk.Label(
            log_toolbar,
            text="开始 / 停止操作位于本客户端；停止后服务端会立即结束对应推流。",
            bg=CARD,
            fg=MUTED,
            font=(UI_FONT, 9),
        ).pack(side="left")
        ttk.Button(log_toolbar, text="清空日志", command=lambda: clear_log(self.log_text)).pack(
            side="right"
        )

        log_wrap, self.log_text = make_log_view(log_body, height=5)
        log_wrap.pack(fill="both", expand=True)

    # ------------------------------------------------------------------ 网卡
    def _refresh_nics(self) -> None:
        previous_ip = self._selected_nic_ip()
        interfaces = list_ipv4_interfaces()
        self._nic_map = {}
        labels: list[str] = []
        for item in interfaces:
            label = f"{item.name} — {item.ip}"
            labels.append(label)
            self._nic_map[label] = item

        self.nic_combo.configure(values=labels)
        keep = next((label for label, nic in self._nic_map.items() if nic.ip == previous_ip), None)
        if keep is None:
            target_ip = None
            server_ip = self.server_var.get().strip()
            if is_valid_ipv4(server_ip):
                target_ip = route_source_ip(server_ip, DEFAULT_PORT)
            if target_ip:
                keep = next(
                    (label for label, nic in self._nic_map.items() if nic.ip == target_ip), None
                )
            if keep is None and labels:
                keep = labels[0]
        self.nic_var.set(keep or "")
        self._update_mac_display()
        if not labels:
            self.detail_label.configure(text="未检测到可用的 IPv4 网卡，请检查网络连接。")

    def _selected_nic(self) -> NicAddress | None:
        return self._nic_map.get(self.nic_var.get())

    def _selected_nic_ip(self) -> str | None:
        nic = self._selected_nic()
        return nic.ip if nic is not None else None

    def _on_nic_selected(self, _event=None) -> None:
        self._update_mac_display()

    def _update_mac_display(self) -> None:
        nic = self._selected_nic()
        mac = nic.mac if nic is not None else ""
        self.mac_var.set(mac or "不可用")
        self.mac_value_label.configure(fg=TEXT if mac else MUTED)

    def _selected_transport(self) -> str:
        value = self.transport_var.get()
        return value if value in TRANSPORTS else DEFAULT_TRANSPORT

    def _selected_rate(self) -> int:
        return RATE_BY_LABEL.get(self.rate_var.get(), DEFAULT_RATE_BPS)

    def _metrics_title(self) -> str:
        return f"接收统计（目标 {format_rate(self._selected_rate())} · {self._selected_transport()}）"

    def _on_selection_change(self, _event=None) -> None:
        label = getattr(self, "metrics_title_label", None)
        if label is not None:
            label.configure(text=self._metrics_title())

    def _match_nic(self) -> None:
        server_ip = self.server_var.get().strip()
        if not is_valid_ipv4(server_ip):
            messagebox.showwarning(
                "无法匹配网卡", "请先填写正确的服务端 IPv4 地址。", parent=self.root
            )
            self.server_entry.focus_set()
            return
        self._refresh_nics()
        source_ip = route_source_ip(server_ip, DEFAULT_PORT)
        for label, nic in self._nic_map.items():
            if nic.ip == source_ip:
                self.nic_var.set(label)
                self._update_mac_display()
                self._enqueue_log("info", f"按系统路由匹配本机网卡：{label}")
                return
        messagebox.showwarning(
            "无法匹配网卡",
            f"系统未返回访问 {server_ip} 的本机地址，请手动选择网卡，或检查网络连接。",
            parent=self.root,
        )

    # ------------------------------------------------------------------ 操作
    def _on_start(self) -> None:
        if self._client_state in ACTIVE_STATES:
            return
        server_ip = self.server_var.get().strip()
        if not is_valid_ipv4(server_ip):
            messagebox.showwarning(
                "服务端 IP 无效",
                "请输入正确的服务端 IPv4 地址，例如 192.168.1.10 或 127.0.0.1。",
                parent=self.root,
            )
            self.server_entry.focus_set()
            return
        bind_ip = self._selected_nic_ip()
        if not bind_ip:
            messagebox.showwarning(
                "未选择网卡", "请选择一块带 IPv4 地址的本机网卡。", parent=self.root
            )
            return
        nic = self._selected_nic()
        mac_text = nic.mac if nic is not None and nic.mac else "不可用"

        self._hide_notice()
        self._enqueue_log("info", f"本机网卡 {nic.name if nic else bind_ip}（{bind_ip}），MAC {mac_text}。")
        try:
            self.client.start(
                server_ip,
                bind_ip,
                DEFAULT_PORT,
                transport=self._selected_transport(),
                rate_bps=self._selected_rate(),
            )
        except Exception as exc:
            self._enqueue_log("error", str(exc))
            messagebox.showerror("无法开始接收", str(exc), parent=self.root)
            return

        set_status(self.status_badge, STATE_TEXT[STATE_CONNECTING][0], ORANGE)
        self._update_controls(STATE_CONNECTING)

    def _on_stop(self) -> None:
        if self._client_state not in ACTIVE_STATES - {STATE_STOPPING}:
            return
        self.client.stop()
        set_status(self.status_badge, STATE_TEXT[STATE_STOPPING][0], ORANGE)
        self._update_controls(STATE_STOPPING)

    # ------------------------------------------------------------------ 状态/统计
    def _poll(self) -> None:
        if self._closing:
            return
        snap = self.client.snapshot()
        state = snap["state"]
        self._client_state = state
        self._update_state(state, snap)
        self._update_metrics(state, snap)
        self._update_controls(state)
        self.root.after(250, self._poll)

    def _update_state(self, state: str, snap: dict) -> None:
        text, color = STATE_TEXT.get(state, ("● 未知状态", MUTED))
        set_status(self.status_badge, text, color)

        if state == STATE_IDLE:
            detail = "请选择传输协议与目标码率，填写服务端 IP、选择本机网卡，然后点击“开始收看”。"
        elif state == STATE_CONNECTING:
            detail = (
                f"正在连接 {snap['server_ip']}:{snap['port']}"
                f"（{snap['transport']} · 目标 {snap['target_rate_text']}，"
                f"本机网卡 {snap['bind_ip']}）…"
            )
        elif state in (STATE_RECEIVING, STATE_STALLED):
            detail = (
                f"服务端 {snap['server_ip']}:{snap['port']} · {snap['transport']} · "
                f"目标 {snap['target_rate_text']} · 本机 {snap['bind_ip']} · "
                f"已接收 {format_duration(snap['connected_seconds'])} · 会话 {snap['session']}"
            )
        elif state == STATE_STOPPING:
            detail = "正在通知服务端停止推流…"
        elif state == STATE_STOPPED:
            detail = "已停止接收；下方保留本次统计，可修改设置后重新开始。"
        else:
            detail = "连接失败，请根据下方提示检查后重试。"
        self.detail_label.configure(text=detail, fg=MUTED)

        notice = ""
        notice_color = RED
        if state == STATE_ERROR and snap["error"]:
            notice = snap["error"]
        elif state == STATE_STALLED:
            notice = "已超过 2 秒未收到数据，连接仍保持；可点击“停止接收”后重试，或检查网络。"
            notice_color = ORANGE
        if notice:
            self.notice_label.configure(text=notice, fg=notice_color)
            if not self._notice_visible:
                self.notice_label.pack(fill="x", pady=(4, 0), after=self.detail_label)
                self._notice_visible = True
        else:
            self._hide_notice()

    def _update_metrics(self, state: str, snap: dict) -> None:
        show_rate = state in (STATE_RECEIVING, STATE_STALLED)
        payload_bps = snap["payload_bps"] if show_rate else 0.0
        wire_bps = snap["wire_bps"] if show_rate else 0.0
        self.rate_value.configure(text=format_rate(payload_bps))
        self.wire_value.configure(text=format_rate(wire_bps))
        self.bytes_value.configure(text=format_bytes(snap["received_bytes"]))
        self.packets_value.configure(text=f"{snap['received_packets']:,}")
        loss_rate = snap["loss_rate"]
        self.loss_value.configure(
            text=f"{loss_rate * 100:.2f}%", fg=GREEN if loss_rate < 0.005 else ORANGE
        )
        self.jitter_value.configure(text=f"{snap['jitter_ms']:.3f} ms")

    def _update_controls(self, state: str) -> None:
        if state == self._controls_state:
            return
        self._controls_state = state
        busy = state in ACTIVE_STATES
        entry_state = "disabled" if busy else "normal"
        combo_state = "disabled" if busy else "readonly"
        self.server_entry.configure(state=entry_state)
        self.nic_combo.configure(state=combo_state)
        self.transport_combo.configure(state=combo_state)
        self.rate_combo.configure(state=combo_state)
        for button in (self.refresh_button, self.match_button):
            button.configure(state="disabled" if busy else "normal")

        can_start = state in (STATE_IDLE, STATE_STOPPED, STATE_ERROR)
        can_stop = state in (STATE_CONNECTING, STATE_RECEIVING, STATE_STALLED)
        self._style_action_button(self.start_button, can_start, ACCENT, "#1d4ed8")
        self._style_action_button(self.stop_button, can_stop, RED, "#991b1b")

    @staticmethod
    def _style_action_button(
        button: tk.Button, enabled: bool, color: str, active_color: str
    ) -> None:
        if enabled:
            button.configure(
                state=tk.NORMAL,
                bg=color,
                fg="white",
                activebackground=active_color,
                disabledforeground="white",
                cursor="hand2",
            )
        else:
            button.configure(
                state=tk.DISABLED,
                bg="#e2e8f0",
                fg="#94a3b8",
                activebackground="#e2e8f0",
                disabledforeground="#94a3b8",
                cursor="arrow",
            )

    def _hide_notice(self) -> None:
        if self._notice_visible:
            self.notice_label.pack_forget()
            self._notice_visible = False

    # ------------------------------------------------------------------ 日志/退出
    def _enqueue_log(self, level: str, message: str) -> None:
        self._log_queue.put((level, message))

    def _drain_logs(self) -> None:
        if self._closing:
            return
        try:
            while True:
                level, message = self._log_queue.get_nowait()
                append_log(self.log_text, level, message)
        except queue.Empty:
            pass
        self.root.after(150, self._drain_logs)

    def _on_close(self) -> None:
        if self._client_state in ACTIVE_STATES and not messagebox.askyesno(
            "退出客户端", "正在接收直播流，退出将停止接收。确定退出？", parent=self.root
        ):
            return
        self._closing = True
        self.client.shutdown()
        self.root.destroy()


def main() -> None:
    enable_dpi_awareness()
    root = tk.Tk()
    ClientApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
