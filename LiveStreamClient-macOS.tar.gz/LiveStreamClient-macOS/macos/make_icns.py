"""生成 macOS 应用图标 macos/AppIcon.icns。用法：python macos/make_icns.py"""

from __future__ import annotations

import io
import struct
import sys
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / "android"))

from make_icons import draw_motif, vertical_gradient  # noqa: E402

CANVAS = 1024
BODY = 824
RADIUS = 185
ICNS_TYPES = (
    ("ic11", 32),
    ("ic12", 64),
    ("ic07", 128),
    ("ic08", 256),
    ("ic13", 256),
    ("ic09", 512),
    ("ic14", 512),
    ("ic10", 1024),
)


def render() -> Image.Image:
    canvas = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0))
    body = vertical_gradient(BODY, (59, 130, 246), (29, 78, 216))
    mask = Image.new("L", (BODY, BODY), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        [0, 0, BODY - 1, BODY - 1], radius=RADIUS, fill=255
    )
    body.putalpha(mask)
    offset = (CANVAS - BODY) // 2
    canvas.alpha_composite(body, (offset, offset))
    draw_motif(canvas, BODY / CANVAS)
    return canvas


def png_bytes(image: Image.Image) -> bytes:
    buffer = io.BytesIO()
    image.save(buffer, format="PNG", optimize=True)
    return buffer.getvalue()


def main() -> None:
    master = render()
    chunks = []
    for kind, size in ICNS_TYPES:
        data = png_bytes(master.resize((size, size), Image.Resampling.LANCZOS))
        chunks.append(kind.encode("ascii") + struct.pack(">I", len(data) + 8) + data)
    payload = b"".join(chunks)
    icns = b"icns" + struct.pack(">I", len(payload) + 8) + payload
    target = ROOT / "AppIcon.icns"
    target.write_bytes(icns)
    master.resize((512, 512), Image.Resampling.LANCZOS).save(ROOT / "AppIcon.png")
    print(f"已生成 {target}（{len(icns)} 字节）")


if __name__ == "__main__":
    main()
