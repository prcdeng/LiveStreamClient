#!/bin/bash
# 在 macOS 上构建“直播流量模拟”客户端 .app（需已安装 Python 3 与 tkinter）。
set -euo pipefail

cd "$(dirname "$0")/.."

PYTHON="${PYTHON:-python3}"

if ! command -v "$PYTHON" >/dev/null 2>&1; then
  echo "未找到 python3。请安装 python.org 的 Python 3（自带 tkinter）："
  echo "  https://www.python.org/downloads/macos/"
  exit 1
fi

if ! "$PYTHON" -c "import tkinter" >/dev/null 2>&1; then
  echo "当前 Python 缺少 tkinter。"
  echo "  - 推荐安装 python.org 版 Python 3；或"
  echo "  - Homebrew 用户可执行：brew install python-tk"
  exit 1
fi

"$PYTHON" -m venv .venv-macos
# shellcheck disable=SC1091
source .venv-macos/bin/activate

python -m pip install --upgrade pip >/dev/null
python -m pip install -r macos/requirements-macos.txt

rm -rf macos/dist macos/build

python -m PyInstaller \
  --noconfirm \
  --clean \
  --windowed \
  --name LiveStreamClient \
  --icon macos/AppIcon.icns \
  --osx-bundle-identifier com.livesim.client \
  --distpath macos/dist \
  --workpath macos/build \
  --specpath macos/build \
  client_app.py

APP="macos/dist/LiveStreamClient.app"
PLIST="$APP/Contents/Info.plist"
if ! /usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName 直播流量模拟" "$PLIST" 2>/dev/null; then
  /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string 直播流量模拟" "$PLIST"
fi

xattr -cr "$APP" 2>/dev/null || true
codesign --force --deep --sign - "$APP"

echo
echo "构建完成：$(pwd)/$APP"
echo "运行：open \"$APP\""
