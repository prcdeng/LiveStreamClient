#!/bin/bash
# 双击即可在 macOS 上以源码方式启动客户端（需要 Python 3 与 tkinter）。
cd "$(dirname "$0")/.." || exit 1

fail() {
  echo "$1"
  echo
  read -r -n 1 -s -p "按任意键退出…"
  echo
  exit 1
}

command -v python3 >/dev/null 2>&1 || fail "未找到 python3。请安装 python.org 的 Python 3（自带 tkinter）：https://www.python.org/downloads/macos/"
python3 -c "import tkinter" >/dev/null 2>&1 || fail "当前 Python 缺少 tkinter。请安装 python.org 版 Python 3，或执行：brew install python-tk"

exec python3 client_app.py
