# 直播流量模拟 · macOS 客户端

与 Windows 服务端（LiveStreamServer.exe）配套使用：客户端可选择 TCP/UDP 与 4/32/128/300 Mbps 预设码率，或输入 1–1000 Mbps 的自定义码率；填写服务端 IP（默认 `10.104.123.246`）、端口固定 9010，并选择本机网卡后开始接收。

> 说明：macOS 应用包（.app）必须在 macOS 上构建，Windows 无法交叉编译。本目录已提供全部源码、图标和一键打包脚本；在 Mac 上执行一条命令即可生成独立 .app。

## 方式一：源码直接运行

需要 Python 3（建议 python.org 安装包，自带 tkinter）。

```bash
cd LiveStreamClient-macOS
pip3 install psutil          # 可选，网卡列表更完整；未安装时使用 ifconfig 兜底
python3 client_app.py
```

也可以双击 `macos/start_client.command`（若提示无权限，先执行 `chmod +x macos/start_client.command`）。

## 方式二：打包成独立 .app（无需目标机安装 Python）

```bash
cd LiveStreamClient-macOS
chmod +x macos/build_macos.sh
./macos/build_macos.sh
open macos/dist/LiveStreamClient.app
```

脚本会自动创建 `.venv-macos` 虚拟环境、安装 PyInstaller/psutil、生成 .app，并做 ad-hoc 签名。产物在 `macos/dist/LiveStreamClient.app`，可拖入“应用程序”目录。

如果从网络传输后打开提示“无法验证开发者”，可右键点击应用选择“打开”，或执行：

```bash
xattr -dr com.apple.quarantine macos/dist/LiveStreamClient.app
```

## 使用提示

- 服务端运行在 Windows 上并监听 0.0.0.0:9010；macOS 客户端填写服务端局域网 IP。客户端是主动出站连接，一般无需在 macOS 防火墙中放行入站。
- 首次填写服务端 IP 后点击“按 IP 匹配”可自动选中访问该地址所用的本机网卡；也可手动从下拉框选择。
- 网卡行右侧会显示所选网卡的 MAC 地址；虚拟网卡或系统隐藏 MAC 时显示“不可用”。
- UDP 接收若出现丢包，多为网络或 Wi-Fi 环境导致；TCP 更稳定但协议开销略高（约 3.5%）。
- 应用内默认码率 4 Mbps、协议 UDP，与服务端互不影响；服务端按客户端的订阅参数推流。选择“自定义”后可填写 1–1000 Mbps（支持小数）。

## 文件说明

| 路径 | 用途 |
| --- | --- |
| `client_app.py` / `client_core.py` | 界面与接收引擎 |
| `common.py` / `ui_common.py` | 协议常量、网卡枚举、界面样式（含 macOS 适配） |
| `macos/build_macos.sh` | 一键构建 .app |
| `macos/start_client.command` | 双击以源码启动 |
| `macos/AppIcon.icns` | 应用图标（由 `make_icns.py` 生成） |
| `macos/requirements-macos.txt` | 构建/运行依赖 |

## 验证边界

协议引擎与界面已在 Windows 上回归（UDP/TCP × 4/32/128/300 Mbps、自定义 10 Mbps、混合并发、停止清理）；macOS 分支（PingFang 字体、ifconfig 网卡兜底、Cmd+Q 退出）已按平台条件实现，但当前环境无法运行 macOS，.app 的构建与真机验证需在你的 Mac 上完成。
